$(function(){
	// add arrow to CTAs
	$('a.more').append('<span>&#9658;</span>');
	// if INPUT doesn't do placeholder, add via JS
	if (!Modernizr.input.placeholder) {
		var s = $('#s'),
			p = s.attr('placeholder');
		if (s.attr('value') === '') { s.attr('value',p); }
		s.focus(function(){
			var me = $(this);
			if (me.attr('value') === me.attr('placeholder')) { me.attr('value',''); }
		})
		.blur(function(){
			var me = $(this);
			if (me.attr('value') === '') { me.attr('value',me.attr('placeholder')); }
		});
	}
	// add Google Map to Contact Us page
	if ($('body:first').hasClass('contact-us')) {
		// address: 101 West 31st Street, 14th Floor, New York, NY 10001
		// http://maps.google.com/maps?f=q&source=s_q&hl=en&geocode=&q=75%2BChristopher%2BStreet,%2BNew%2BYork,%2BNY%2B10014-4236&sll=37.0625,-95.677068&sspn=50.644639,77.080078&ie=UTF8&hq=&hnear=75+Christopher+St,+New+York,+10014&z=14&output=embed&iwloc=near
		var a = String('101 West 31st Street, 14th Floor, New York, NY 10001').split(' ').join('+'),
			h = [],
			p = $('#content').find('h2:first'),
			s = 'http://maps.google.com/maps?f=q&source=s_q&hl=en&geocode=&q='+a+'&ie=UTF8&hq=&hnear='+a+'&z=14&iwloc=near';
		h.push('<div id="google-map">');
		h.push('<iframe width="350" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="',s,'&output=embed"></iframe><br />');
		h.push('<p class="more"><a href="',s,'" target="_blank">View Larger Map</a></p>');
		h.push('</div>');
		p.after(h.join(''));
	}
	// add Google Translate link to bottom nav
	$.getScript('http://translate.google.com/translate_a/element.js?cb=MGI.googletranslate');
});
var MGI = {
	googletranslate : function() {
		new google.translate.TranslateElement({pageLanguage:'en'},'nav-translate');
	}
}
