<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the wordpress construct of pages
 * and that other 'pages' on your wordpress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Boilerplate
 * @since Boilerplate 1.0
 */

get_header(); ?>
		<div id="main">
<?php
	/*$bodyclass = boilerplate_body_class();
	// determine correct header, subnav & image
	if (strlen(strstr($bodyclass,'students')) > 0) {
		echo '			<section id="top" role="navigation">
							<h2>Dreaming of College?</h2>'.PHP_EOL;
		wp_nav_menu( array( 'container' => 'false', 'menu' => '10' ) );
		echo '				<img src="'. home_url( ) .'/wp-content/uploads/students-top.jpg" width="494" height="270" alt="Let MGI Gear Up help you get ready for college" />
						</section><!-- #top -->'.PHP_EOL;
	} else if (strlen(strstr($bodyclass,'parents')) > 0) {
		echo '			<section id="top" role="navigation">
							<h2>Is Your Child Ready for College?</h2>'.PHP_EOL;
		wp_nav_menu( array( 'container' => 'false', 'menu' => '11' ) );
		echo '				<img src="'. home_url( ) .'/wp-content/uploads/parent-top.jpg" width="494" height="270" alt="Let MGI Gear Up help your child get ready for college" />
						</section><!-- #top -->'.PHP_EOL;
	} else if (strlen(strstr($bodyclass,'alumni')) > 0) {
		echo '			<section id="top" role="navigation">
							<h2>What\'s Next After College?</h2>'.PHP_EOL;
		wp_nav_menu( array( 'container' => 'false', 'menu' => '12' ) );
		echo '				<img src="'. home_url( ) .'/wp-content/uploads/alumni-top.jpg" width="494" height="270" alt="Let MGI Gear Up help your child get ready for college" />
						</section><!-- #top -->'.PHP_EOL;
	}*/
?>			<section id="content" role="main">
				<h1><?php the_title(); ?></h1>
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<div class="entry-content">
						<?php the_content(); ?>
					</div><!-- .entry-content -->
				</article><!-- #post-## -->
<?php endwhile; ?>
			</section><!-- #content -->
		</div><!-- #main -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
