<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the wordpress construct of pages
 * and that other 'pages' on your wordpress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Boilerplate
 * @since Boilerplate 1.0
 * Template Name: Calendar
*/
get_header(); ?>
		<div id="main">
			<section id="top">
				<h2><span>Dates</span> <abbr title="and">&amp;</abbr> <span>Deadlines</span></h2>
				<iframe src="https://www.google.com/calendar/b/0/embed?title=&nbsp;&amp;wkst=1&amp;bgcolor=%23F1F7FC&amp;src=o1gv4fhl1t0e2t79gdti44p330%40group.calendar.google.com&amp;color=%236D2368&amp;ctz=America/New_York" style="border-width:0;" width="732" height="600" frameborder="0" scrolling="no"></iframe>
			</section><!-- #content -->
		</div><!-- #main -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
