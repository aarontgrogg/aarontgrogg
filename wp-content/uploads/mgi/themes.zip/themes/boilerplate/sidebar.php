<?php
/**
 * The Sidebar containing the primary and secondary widget areas.
 *
 * @package WordPress
 * @subpackage Boilerplate
 * @since Boilerplate 1.0
 */
?>

		<div id="sidebar">
			<section id="news-widget" role="complementary">
				<?php echo mgi_gear_up_news(); ?>
			</section><!-- #news-widget -->
			<section id="fafsa-widget" role="complementary">
				<?php echo mgi_fafsa(); ?>
			</section><!-- #fafsa-widget -->
			<section id="apply-widget" role="complementary">
				<?php echo mgi_apply_to_cuny(); ?>
			</section><!-- #apply-widget -->
			<section id="student-of-the-month-widget" role="complementary">
				<?php echo mgi_student_of_the_month(); ?>
			</section><!-- #student-of-the-month-widget -->
		</div><!-- #sidebar -->
