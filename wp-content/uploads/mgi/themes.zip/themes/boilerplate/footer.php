<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content
 * after.  Calls sidebar-footer.php for bottom widgets.
 *
 * @package WordPress
 * @subpackage Boilerplate
 * @since Boilerplate 1.0
 */
?>
		<footer role="contentinfo">
<?php
	/* A sidebar in the footer? Yep. You can can customize
	 * your footer with four columns of widgets.
	 */
	get_sidebar( 'footer' );
?>
			<ul class="vcard">
				<li class="org fn">CUNY MGI Gear Up</li>
				<li class="adr"><span class="street-address">101 West 31st Street, 14th Floor</span></li>
				<li><span class="locality">New York</span>, <abbr class="region" title="New York">NY</abbr> <span class="postal-code">10001 </span></li>
				<li class="tel">646-344-7354</li>
				<li class="url"><a href="http://mgi.cuny.edu/" title="CUNY MGI Gear Up website">http://mgi.cuny.edu/</a></li>
				<li class="email"><a href="mailto:info@nygearup.org" title="Email CUNY Gear Up">info@nygearup.org</a></li>
			</ul>
			<div id="cunylogo">Middle Grades Initiative is CUNY</div>
		</footer><!-- footer -->
		<div class="clearfix"></div>
<?php
	/* Always have wp_footer() just before the closing </body>
	 * tag of your theme, or you will break many plugins, which
	 * generally use this hook to reference JavaScript files.
	 */
	wp_footer();
?>
	</body>
</html>
