<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package WordPress
 * @subpackage Boilerplate
 * @since Boilerplate 1.0
 */

get_header(); ?>
		<div id="main" class="page-not-found">
			<section id="content" role="main">
				<h2><?php _e( 'Oops, we can\'t seem to find what you were looking for...', 'boilerplate' ); ?></h2>
				<p><?php _e( 'Maybe try the above options or try searching for something?', 'boilerplate' ); ?></p>
			</section><!-- #content -->
		</div><!-- #main -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
