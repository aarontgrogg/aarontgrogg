<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the wordpress construct of pages
 * and that other 'pages' on your wordpress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Boilerplate
 * @since Boilerplate 1.0
 * Template Name: Section
 */

get_header(); ?>
		<div id="main" class="section">
			<section id="top" role="navigation">
<?php
	$bodyclass = boilerplate_body_class();
	// determine correct header, subnav & image
	if (strlen(strstr($bodyclass,'students')) > 0) {
		echo '				<h2>Dreaming of College?</h2>'.PHP_EOL;
		wp_nav_menu( array( 'container' => 'false', 'menu' => 'Students Sub' ) );
		echo '				<img src="'. home_url( ) .'/wp-content/uploads/2011/03/students-top.jpg" width="494" height="270" alt="Let MGI Gear Up help you get ready for college" />'.PHP_EOL;
	} else if (strlen(strstr($bodyclass,'parents')) > 0) {
		echo '				<h2>Is Your Child Ready for College?</h2>'.PHP_EOL;
		wp_nav_menu( array( 'container' => 'false', 'menu' => 'Parents Sub' ) );
		echo '				<img src="'. home_url( ) .'/wp-content/uploads/2011/03/parent-top.jpg" width="494" height="270" alt="Let MGI Gear Up help your child get ready for college" />'.PHP_EOL;
	} else if (strlen(strstr($bodyclass,'alumni')) > 0) {
		echo '				<h2>What\'s Next After College?</h2>'.PHP_EOL;
		wp_nav_menu( array( 'container' => 'false', 'menu' => 'Alumni Sub' ) );
		echo '				<img src="'. home_url( ) .'/wp-content/uploads/2011/03/alumni-top.jpg" width="494" height="270" alt="Let MGI Gear Up help your child get ready for college" />'.PHP_EOL;
	}
?>
						</section><!-- #top -->			<section id="content" role="main">
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<div class="entry-content">
						<?php the_content(); ?>
					</div><!-- .entry-content -->
				</article><!-- #post-## -->
<?php endwhile; ?>
			</section><!-- #content -->
		</div><!-- #main -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
