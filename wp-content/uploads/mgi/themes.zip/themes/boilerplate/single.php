<?php
/**
 * The Template for displaying all single posts.
 *
 * @package WordPress
 * @subpackage Boilerplate
 * @since Boilerplate 1.0
 */

get_header(); ?>
		<div id="main" class="permalink">
			<section id="content" role="main">
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<h1><?php the_title(); ?></h1>
					<div class="entry-meta">
						<?php boilerplate_posted_on(); ?>
						<?php if ( count( get_the_category() ) ) : ?>
							<?php printf( __( 'in %2$s', 'boilerplate' ), 'entry-utility-prep entry-utility-prep-cat-links', get_the_category_list( ', ' ) ); ?>
						<?php endif; ?>
						<?php
							$tags_list = get_the_tag_list( '', ', ' );
							if ( $tags_list ):
						?>
							| <?php printf( __( 'Tagged %2$s', 'boilerplate' ), 'entry-utility-prep entry-utility-prep-tag-links', $tags_list ); ?>
						<?php endif; ?>
						<?php //comments_popup_link( __( 'Leave a comment', 'boilerplate' ), __( '1 Comment', 'boilerplate' ), __( '% Comments', 'boilerplate' ) ); ?>
						<?php //edit_post_link( __( 'Edit', 'boilerplate' ), '| ', '' ); ?>
					</div><!-- .entry-meta -->
					<div class="entry-content">
						<?php the_content(); ?>
					</div><!-- .entry-content -->
				</article><!-- #post-## -->
<?php endwhile;
	$bodyclass = boilerplate_body_class();
	// determine correct header, subnav & image
	if (strlen(strstr($bodyclass,'student-of-the-month')) > 0) {
		$cat_name = 'Student of the Month';
	} else if (strlen(strstr($bodyclass,'newsletters')) > 0) {
		$cat_name = 'Newsletters';
	} else {
		$cat_name = 'News';
	}
	$cat_id = get_cat_ID( $cat_name );
	$cat_link = get_category_link( $cat_id );
	echo '			<p><a class="more" href="'. $cat_link .'">View more ' . $cat_name . (($cat_name === 'Newsletters') ? '' : ' articles') .'</a></p>'.PHP_EOL;
?>			</section><!-- #content -->
		</div><!-- #main -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
